/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Region;

import java.util.ArrayList;

/**
 *
 * @author lx
 */
public class RegionDirectory {
    private ArrayList<Region> regionList;
    
    public RegionDirectory(){
        regionList = new ArrayList<>();
    }

    public ArrayList<Region> getRegionList() {
        return regionList;
    }

}
