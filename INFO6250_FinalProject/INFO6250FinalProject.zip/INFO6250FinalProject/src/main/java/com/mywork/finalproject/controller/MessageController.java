package com.mywork.finalproject.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.mywork.finalproject.dao.MessageDAO;
import com.mywork.finalproject.dao.UserDAO;
import com.mywork.finalproject.pojo.Message;
import com.mywork.finalproject.pojo.Student;
import com.mywork.finalproject.pojo.Teacher;
import com.mywork.finalproject.pojo.User;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Controller
public class MessageController {

	@RequestMapping(value = "/messages.htm", method = RequestMethod.GET)
	public String showMessagePage(HttpServletRequest request, MessageDAO messageDao, UserDAO userDao, ModelMap map) {
		HttpSession session = request.getSession();
		User currentUser = (User) session.getAttribute("user");
		String action = request.getParameter("action");
		
		if (action.equals("inbox")) {
			String receiverUsername = currentUser.getUsername();
			List<Message> messageList = messageDao.getByReceiver(receiverUsername);
			map.addAttribute("messageList", messageList);
			return "messagesInbox";
		} else if (action.equals("compose")) {
			map.addAttribute("sender", currentUser);
			String reply = request.getParameter("reply");
			if (reply == null) {
				return "messagesCompose";
			}else if (reply.equals("yes")) {
				map.addAttribute("replySender", currentUser);
				String subject = request.getParameter("subject");
				map.addAttribute("receiver", request.getParameter("replyReceiver"));
				map.addAttribute("reply", "yes");
				map.addAttribute("subject", subject);
				return "messagesCompose";
			}
		} else if (action.equals("reply")) {
			return "messagesInbox";
		} else if(action.equals("delete")) {
		    int messageid = Integer.parseInt(request.getParameter("messageid"));
		    messageDao.delete(messageid);
		    return "redirect:/messages.htm?action=inbox";
		}
		return null;
	}

	@RequestMapping(value = "/messages.htm", method = RequestMethod.POST)
	public String handleMessagesRequests(@RequestParam("attachedfile") MultipartFile file, HttpServletRequest request, UserDAO userDao, MessageDAO messageDao, ModelMap map) throws Exception {
		String action = request.getParameter("action");
		
		if (action.equals("compose")) {
			HttpSession session = request.getSession();
			String receivername = request.getParameter("receiver");
			String subject = request.getParameter("subject");
			String content = request.getParameter("content");
			String replyFlag = request.getParameter("replyFlag");

			Message message = new Message();
			message.setSubject(subject);
			String username = "";
			if(userDao.getStudent(receivername) == null) {
				username = userDao.getTeacher(receivername).getUsername();				
			}else {
				username = userDao.getStudent(receivername).getUsername();			
			}
			User receiver = userDao.get(username);
			message.setReceiver(receiver.getUsername());
			User sender = (User) session.getAttribute("user");
			message.setSender(sender.getUsername());
			
			message.setContent(content);
			// 判断这个文件不为空
			if (!file.isEmpty()) {
				// 服务端的images目录需要手动创建好,上传到服务器目录下
				// String path = session.getServletContext().getRealPath("/images");
				String path = "/Users/lx/Sites/INFO6250FinalProject";
				// 获取原始文件名
				String fileName = file.getOriginalFilename();
				// 截取文件的扩展名
				String extName = fileName.substring(fileName.lastIndexOf("."));
				File myFile = new File(path, fileName);
				// 完成文件上传
				file.transferTo(myFile);

				message.setAttachedfile(fileName);
			}
			messageDao.create(message);
			if (replyFlag == null) {
				return "redirect:/messages.htm?action=inbox";
			}
			if (replyFlag.equals("finished")) {
				String text = "You have successfully replied to " + receiver.getUsername();
				map.addAttribute("content", text);
				return "success";
			}
		}
		return null;
	}
	
	@RequestMapping(value = "/message/downloadFile.htm", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downloadAssignment(HttpServletRequest request, @RequestParam("filename") String filename, ModelMap model) throws Exception {

		String path = "/Users/lx/Sites/INFO6250FinalProject";
		File file = new File(path + File.separator + filename);
		HttpHeaders headers = new HttpHeaders();
		// 下载显示的文件名，解决中文名称乱码问题
		String downloadFileName = new String(filename.getBytes("UTF-8"), "iso-8859-1");
		// 通知浏览器以attachment（下载方式）打开图片
		headers.setContentDispositionFormData("attachment", downloadFileName);
		// application/octet-stream ： 二进制流数据（最常见的文件下载）。
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file), headers, HttpStatus.CREATED);
	}
	
}
