package com.mywork.finalproject.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import com.mywork.finalproject.pojo.Student;
import com.mywork.finalproject.pojo.Teacher;
import com.mywork.finalproject.pojo.User;

public class UserDAO extends DAO {

	public User register(User u) throws Exception
    {
        try{
            begin();
            getSession().save(u);
            commit();
            return u;
        }catch(HibernateException e){
            rollback();
           throw new Exception("Exception while creating user: " + e.getMessage());
        }
    }
       
    public User get(String username){
        try{
            begin();
            Query q = getSession().createQuery("from User where username = :username");
            q.setString("username", username);
            User user = (User) q.uniqueResult();
            close();
            return user;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public Student getStudent(String name){
        try{
            begin();
            Query q = getSession().createQuery("from Student where name = :name");
            q.setString("name", name);
            Student student = (Student) q.uniqueResult();
            close();
            return student;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public Teacher getTeacher(String name){
        try{
            begin();
            Query q = getSession().createQuery("from User where name = :name");
            q.setString("name", name);
            Teacher teacher = (Teacher) q.uniqueResult();
            close();
            return teacher;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public ArrayList<User> getAll(){
        try{
            begin();
            Query q = getSession().createQuery("from User");
            ArrayList<User> list = (ArrayList)q.list();
            close();
            return list;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public ArrayList<Teacher> getAllTeacher(){
        try{
            begin();
            Query q = getSession().createQuery("from Teacher");
            ArrayList<Teacher> list = (ArrayList)q.list();
            close();
            return list;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public ArrayList<Student> getAllStudent(){
        try{
            begin();
            Query q = getSession().createQuery("from Student");
            ArrayList<Student> list = (ArrayList)q.list();
            close();
            return list;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public User get(String username,String password)
    {
        try {
            begin();
            Query q = getSession().createQuery("from User where username = :username and password = :password");
            q.setString("username", username);
            q.setString("password", password);
            User user = (User) q.uniqueResult();
            if(user == null){
                
            }else{
                close();
                return user;
            }
            
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
            return null;
    }
    
    public boolean updateUser(String username) throws Exception {
        try{
            begin();
            Query q = getSession().createQuery("from User where username = :username");
            q.setString("username", username);
            User user = (User)q.uniqueResult();
            if(user != null){
                user.setStatus(1);
                getSession().update(user);
                commit();
                return true;
            }else{
                return false;
            }
        }catch(HibernateException e){
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    }
    
    public boolean updateStudent(String id, String name, String age, String gender,
                                 String city, String state, String zipCode) throws Exception {
        try {
            begin();
            Query q = getSession().createQuery("from Student where id = :id");
            q.setString("id", id);
            Student student = (Student)q.uniqueResult();
            if(student != null){
                student.setName(name);
                student.setAge(Integer.parseInt(age));
                student.setGender(gender);
                student.setCity(city);
                student.setState(state);
                student.setZipCode(zipCode);
                getSession().update(student);
                commit();
                close();
                return true;
            }else{
                return false;
            }
        }catch(HibernateException e){
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }       
    }
    
    public boolean updateTeacher(String id, String name, String age, String gender, String subject)throws Exception{
        try{
            begin();
            Query q = getSession().createQuery("from Teacher where id = :id");
            q.setString("id", id);
            Teacher teacher = (Teacher)q.uniqueResult();
            if(teacher != null){
                teacher.setName(name);
                teacher.setAge(Integer.parseInt(age));
                teacher.setGender(gender);
                teacher.setSubject(subject);
                getSession().update(teacher);
                commit();
                close();
                return true;
            }else{
                return false;
            }         
        }catch(HibernateException e){
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    }
    
    public boolean updateUserPassword(String id, String password) throws Exception{
        try{
            begin();
            Query q = getSession().createQuery("from User where id = :id");
            q.setString("id", id);
            User user = (User) q.uniqueResult();
            if(user != null){
                user.setPassword(password);
                getSession().update(user);
                commit();
                return true;
            }else{
                return false;
            }
        }catch(HibernateException e){
            rollback();
            throw new Exception("Exception while creating user: " + e.getMessage());
        }
    }
    
    public Student addInfo(Student student) throws Exception{
        try {
            begin();
            getSession().save(student);
            commit();
            return student;

        } catch (HibernateException e) {
            rollback();
            throw new Exception("Exception : " + e.getMessage());
        }
    }
}
