package com.mywork.finalproject.controller;

import com.captcha.botdetect.web.servlet.Captcha;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.logging.Level;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.mywork.finalproject.dao.UserDAO;
import com.mywork.finalproject.pojo.Student;
import com.mywork.finalproject.pojo.Teacher;
import com.mywork.finalproject.pojo.User;

/**
 * Handles requests for the application home page.
 */

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/user/register.htm", method = RequestMethod.GET)
	public String home() {	
		return "userRegisterForm";		
	}
	
	@RequestMapping(value = "/user/register.htm", method = RequestMethod.POST)
    public String handleRegisterForm(HttpServletRequest request, UserDAO userDao, ModelMap map){
        String username = request.getParameter("username");
        
        
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        
        Captcha captcha = Captcha.load(request, "CaptchaObject");
        String captchaCode = request.getParameter("captchaCode");
               
        if(userDao.get(username)!=null){
            map.addAttribute("errorMessage", "This Email has been registered!");
            return "error";
        }
        
        if(captcha.validate(captchaCode))
        {
            HttpSession session = request.getSession();
            User user = new User();
            if (role.equals("student")) 
            {
            	user = new Student();
            } 
            else if (role.equals("teacher")) 
            {
            	user = new Teacher();
            }
            
            user.setUsername(username);
            user.setPassword(password);
            user.setStatus(0);//0代表未激活，1代表已激活

            try{
                User u = userDao.register(user);
                Random rand = new Random();
                int randomNum1 = rand.nextInt(5000000);
                int randomNum2 = rand.nextInt(5000000);
                try{
                    String str = "http://localhost:8080/finalproject/user/validateemail.htm?username=" + username + "&key1="
							+ randomNum1 + "&key2=" + randomNum2 + "&role=" + role;
                    session.setAttribute("newUser", u);
                    session.setAttribute("key1", randomNum1);
                    session.setAttribute("key2", randomNum2);
                    sendEmail(username, "Click on this link to activate your account : " + str);
                }catch(Exception e){
                    System.out.println("Email cannot be sent");
                }
            }catch(Exception e){
                e.printStackTrace();
            }        
        }else{
            map.addAttribute("errorMessage", "Invalid Captcha!");
            return "userRegisterForm";
        } 
        return "userCreated";
    }
    
    public void sendEmail(String useremail, String message) {
        try {
            Email email = new SimpleEmail();
            email.setHostName("smtp.googlemail.com");
            email.setSmtpPort(465);      
            email.setAuthenticator(new DefaultAuthenticator("kuku.xiao1026@gmail.com", "sb4827590"));
            email.setSSLOnConnect(true);
            email.setFrom("kuku.xiao1026@gmail.com"); // This user email does not exist.
            email.setSubject("INFO6250 FinalProjrct");
            email.setMsg(message); // Retrieve email from the DAO and send this
            email.addTo(useremail);
            email.send();
            
        } catch (EmailException ex) {
            java.util.logging.Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @RequestMapping(value = "/user/login.htm", method = RequestMethod.GET)
    public String showLoginForm() {
    	return "home";
    }
    
    @RequestMapping(value = "/user/login.htm", method = RequestMethod.POST)
    public String handleLoginForm(HttpServletRequest request, UserDAO userDao, ModelMap map){
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try{
            User user = userDao.get(username, password);
            if(user != null && user.getStatus() == 0)
            {
                map.addAttribute("errorMessage", "Please activate your account to login!");
                return "error";
            }
            else if(user != null && user.getStatus() == 1)
            {
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                if (user instanceof Student) 
                {
                	session.removeAttribute("list");
                	ArrayList<User> list = userDao.getAll();
                	for(int i=0;i<list.size();i++) {
                		if(list.get(i).getId() == user.getId()) {
                			list.remove(i);
                		}
                	}
    				session.setAttribute("list",list);
                    return "studentDashboard";
                } else if (user instanceof Teacher) 
                {
                	session.removeAttribute("list");
                	ArrayList<User> list = userDao.getAll();
                	for(int i=0;i<list.size();i++) {
                		if(list.get(i).getId() == user.getId()) {
                			list.remove(i);
                		}
                	}
    				session.setAttribute("list",list);
                    return "teacherDashboard";
                }
                               
            }else
            {
                map.addAttribute("errorMessage", "Invalid username/password!");
                return "error";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @RequestMapping(value = "/user/validateemail.htm", method = RequestMethod.GET)
    public String validateemail(HttpServletRequest request, UserDAO userDao, ModelMap map){
        HttpSession session = request.getSession();
        String username = request.getParameter("username");
        int key1 = Integer.parseInt(request.getParameter("key1"));
        int key2 = Integer.parseInt(request.getParameter("key2"));

        if((Integer)(session.getAttribute("key1")) == key1 && (Integer)(session.getAttribute("key2")) == key2)
        {
            try{
                boolean updateStatus = userDao.updateUser(username);
		if (updateStatus) {                
                    return "home";
		} else {
                    return "error";
		}
            }catch(Exception e){
                e.printStackTrace();
            }
        }else{
            map.addAttribute("errorMessage", "Link expired , generate new link");
            map.addAttribute("resendLink", true);
            return "error";
        }
        return "home";
    }
    
    @RequestMapping(value = "/user/forgotpassword.htm", method = RequestMethod.POST)
    public String handleForgotPasswordForm(HttpServletRequest request, UserDAO userDao){
        String username = request.getParameter("username");
	Captcha captcha = Captcha.load(request, "CaptchaObject");
	String captchaCode = request.getParameter("captchaCode");
        User user = userDao.get(username);
        
        if (captcha.validate(captchaCode) && user != null) {          
            sendEmail(username, "Your password is : " + user.getPassword());
            return "forgotPasswordSuccess";
	} else {
            request.setAttribute("captchamsg", "Captcha is not valid");
            return "forgotPassword";
	}
    }
    
    @RequestMapping(value = "/user/forgotpassword.htm", method = RequestMethod.GET)
    public String getForgotPasswordForm() {
        return "forgotPassword";
    }
}
