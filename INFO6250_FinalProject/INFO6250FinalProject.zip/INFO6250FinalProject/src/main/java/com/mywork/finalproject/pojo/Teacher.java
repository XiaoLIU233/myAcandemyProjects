package com.mywork.finalproject.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Teacher extends User{
	
	public Teacher() {
        super();
    }
    
    @Column(name="name")
    private String name;
    
    @Column(name="age")
    private int age;
    
    @Column(name="gender")
    private String gender;
    
    @Column(name="subject")
    private String subject;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
