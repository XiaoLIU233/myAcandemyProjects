package com.mywork.finalproject.dao;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DAO {

	public DAO() {
    }
	
	static final Logger log = Logger.getAnonymousLogger();
    private final SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session;
    
    public Session getSession() throws Exception
    {
        if(session == null || !session.isOpen())
        {
            session = sf.openSession();
        }
        return session;
    }
    
    public void begin() throws Exception
    {
        getSession().beginTransaction();
    }
    
    public void commit() throws Exception{
        getSession().getTransaction().commit();
    }
    
    public void rollback() throws Exception
    {
        try{
            getSession().getTransaction().rollback();
        }
        catch(HibernateException e){
            log.log(Level.WARNING, "Cannot rollback", e);
        }
    }
    
    public void close() throws Exception 
    {
       getSession().close();
   }

}
