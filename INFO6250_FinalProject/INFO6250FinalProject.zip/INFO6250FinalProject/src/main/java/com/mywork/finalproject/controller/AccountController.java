package com.mywork.finalproject.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mywork.finalproject.dao.UserDAO;
import com.mywork.finalproject.pojo.Student;
import com.mywork.finalproject.pojo.Teacher;
import com.mywork.finalproject.pojo.User;

@Controller
public class AccountController {

	@RequestMapping(value = "/accountInfo/show.htm", method = RequestMethod.GET)
	 public String showAccountInfo(HttpServletRequest request, ModelMap map){
		HttpSession session = request.getSession();
		User currentUser = (User)session.getAttribute("user");
		// prepare for showing different info in jsp page
		if(currentUser instanceof Student) {
			Student student = (Student) currentUser;
			map.addAttribute("student", student);
			return "studentInfo";
		}
		else if(currentUser instanceof Teacher) {
			Teacher teacher = (Teacher) currentUser;
			map.addAttribute("teacher", teacher);
			return "teacherInfo";
		}
		 return null;
	 }
	
	
	 @RequestMapping(value = "/accountInfo/changeInfo.htm", method = RequestMethod.GET)
	 public String changeAccount(HttpServletRequest request, ModelMap map){
		HttpSession session = request.getSession();
		User currentUser = (User)session.getAttribute("user");
		// prepare for showing different info in jsp page
		if(currentUser instanceof Student) {
			Student student = (Student) currentUser;
			map.addAttribute("student", student);
		}
		else if(currentUser instanceof Teacher) {
			Teacher teacher = (Teacher) currentUser;
			map.addAttribute("teacher", teacher);
		}
		 return "changeAccountInfo";
	 }
	 
	 @RequestMapping(value = "/accountInfo/changeInfo.htm", method = RequestMethod.POST)
	 public String changeResult(HttpServletRequest request, UserDAO userDao, ModelMap map)throws Exception{
		 HttpSession session = request.getSession();
		 User currentUser = (User)session.getAttribute("user");
		 int accountId = currentUser.getId();
		 
		 String name = request.getParameter("name");
		 String age = request.getParameter("age");
		 String gender = request.getParameter("gender");
		 
		 if(currentUser instanceof Student) {
				String city = request.getParameter("city");
				String state = request.getParameter("state");
				String zipCode = request.getParameter("zipCode");
				userDao.updateStudent(accountId+"", name, age, gender, city, state, zipCode);
			}
			else if(currentUser instanceof Teacher) {
				String subject = request.getParameter("subject");
				userDao.updateTeacher(accountId+"", name, age, gender, subject);
			}
		 return "changeInfoSuccess";
	 }
	 
	 @RequestMapping(value = "/accountInfo/changePw.htm", method = RequestMethod.GET)
	 public String changePw(HttpServletRequest request, UserDAO userDao, ModelMap map){
		return "changePassword";
	 }
	 
	 @RequestMapping(value = "/accountInfo/changePw.htm", method = RequestMethod.POST)
	 public String showNewPw(HttpServletRequest request, UserDAO userDao, ModelMap map)throws Exception{
		 HttpSession session = request.getSession();
		 User currentUser = (User)session.getAttribute("user");
		 
		 String oldPw = request.getParameter("oldPw");
		 String newPw = request.getParameter("newPw");
		 
		 if(oldPw.equals(newPw)){
	            map.addAttribute("errorMessage", "The two passwords must be not same");
	            return "error";
	     }
	     else{
	            if(currentUser.getPassword().equals(oldPw)){
	                userDao.updateUserPassword(currentUser.getId()+"", newPw);
	                return "changeInfoSuccess";
	            }
	            else {
	            	map.addAttribute("errorMessage", "The old password is wrong!");
	        	    return "error";
	            }
	    }        
	 }
}
